@echo off
setlocal
 echo ==================================================
 echo Windows 11 UEFI recovery - READ-ONLY diagnostics
 echo ==================================================
 echo Run from an elevated WinRE Command Prompt.
 echo Drive letters can differ in WinRE.
 echo.
 echo --- Disks and volumes ---
 (echo list disk&echo list volume) | diskpart
 echo.
 echo --- Boot entries ---
 bcdedit /enum {bootmgr}
 bcdedit /enum {default}
 echo.
 echo --- BitLocker volumes ---
 manage-bde -status
 echo.
 echo No disk or boot changes were made by this script.
 pause
endlocal
