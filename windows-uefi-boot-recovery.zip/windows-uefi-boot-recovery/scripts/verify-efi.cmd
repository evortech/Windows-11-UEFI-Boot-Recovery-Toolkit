@echo off
setlocal
 echo This script only LISTS an already-mounted EFI partition.
 echo It does not assign drive letters or modify boot files.
 set /p ESP=Enter VERIFIED EFI drive letter (example S): 
 echo %ESP%| findstr /R /I "^[A-Z]$" >nul
 if errorlevel 1 (
   echo Invalid letter. Enter one alphabetic character.
   exit /b 1
 )
 if not exist "%ESP%:\EFI\" (
   echo EFI folder not found. Verify the partition before proceeding.
   exit /b 1
 )
 dir "%ESP%:\EFI"
 echo No changes made.
endlocal
