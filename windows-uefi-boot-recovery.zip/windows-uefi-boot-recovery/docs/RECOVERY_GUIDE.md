# Recovering a Windows 11 UEFI boot loop

These steps describe the successful case. **Drive letters and volume numbers are examples, not universal instructions.**

## 1. Open the recovery console

From **Choose an option**, go to **Troubleshoot → Advanced options → Command Prompt**. The prompt may show `X:\Windows\System32>` because WinRE runs from a temporary environment.

## 2. Identify the disk and volumes

```text
diskpart
list disk
list volume
```

A `*` under `Gpt` indicates a GPT disk. Find the large NTFS Windows partition and the small FAT32 EFI partition, but **do not identify the ESP by size alone**. If uncertain, inspect partitions with:

```text
select disk 0
list partition
select partition <ESP_PARTITION_NUMBER>
detail partition
```

`disk 0` is only an example: select the correct disk based on your own results. For a standard GPT ESP, the partition type GUID is `c12a7328-f81f-11d2-ba4b-00a0c93ec93b`.

Leave DiskPart with `exit`. Confirm the Windows directory using each likely drive letter:

```text
dir D:\Windows
```

In the documented case Windows was on `D:`.

## 3. Run non-destructive checks

```text
chkdsk D:
sfc /scannow /offbootdir=D:\ /offwindir=D:\Windows
bcdedit /enum {default}
bcdedit /enum {bootmgr}
manage-bde -status D:
```

Replace `D:` with the verified Windows volume. Plain `chkdsk` is read-only; `chkdsk /f` modifies the file system and should only be used when needed, after assessing backup options. The offline SFC command checks protected Windows files. `manage-bde` checks BitLocker status. A clean result does not prove the boot configuration is correct.

## 4. Assign a temporary letter to the EFI System Partition

**Only after positively identifying the ESP**, enter:

```text
diskpart
select disk 0
select partition <VERIFIED_ESP_PARTITION_NUMBER>
assign letter=S
exit
```

If `S:` is already in use, choose a free letter. Confirm the directory exists:

```text
dir S:\EFI
```

If the EFI directory is absent or the partition identity is unclear, stop and reassess. The ESP in the documented case already contained `Microsoft` and `Boot` directories.

## 5. Recreate Windows UEFI boot files

Once both locations are confirmed, run:

```text
bcdboot D:\Windows /s S: /f UEFI
```

Expected success message:

```text
Boot files successfully created.
```

`bcdboot` copies/creates boot files and can alter boot configuration. With `/s`, firmware boot entry behavior can differ; check UEFI boot order if Windows does not start. On dual-boot systems, the preferred boot entry may change.

## 6. Restart and verify

Type `exit`, close the console, and choose **Continue → Exit and continue to Windows 11**. After a successful boot, back up important files and check **System Information → BIOS Mode: UEFI** and **Disk Management**.

## If it still loops

Do not repeat destructive operations. Record the exact error message, check Startup Repair, recent updates, boot order, and storage health. Consider professional data recovery if the drive has hardware symptoms.
