# Safety checklist

- [ ] Identify the internal disk and confirm whether it is GPT (`diskpart` → `list disk`).
- [ ] Verify the actual Windows directory with `dir <letter>:\Windows`.
- [ ] Identify the EFI System Partition (ESP) using `list partition` and `detail partition`, not size alone. The ESP is usually FAT32.
- [ ] Back up important data first when possible.
- [ ] If BitLocker is enabled, obtain the recovery key before proceeding.
- [ ] Confirm the PC is booting in UEFI mode.
- [ ] Do not format, clean, or delete any partition.
- [ ] Do not run commands against a drive letter merely because it matched an example.

`bcdboot` changes boot files/configuration. Dual-boot systems (e.g., Ubuntu + Windows) may need boot-order adjustments afterward. Stop if partition identity is uncertain.
