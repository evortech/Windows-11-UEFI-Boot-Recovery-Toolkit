# Case study: Windows 11 recovery loop

## Environment

- Windows 11, UEFI/GPT
- One 119 GB GPT disk reported by DiskPart
- Windows installation found on `D:` (117 GB NTFS)
- EFI System Partition: approximately 299 MB FAT32, hidden, initially without a letter
- Other small NTFS recovery/system partitions also present

## Diagnostics

- `chkdsk D:` completed: **no file-system problems**, **0 KB in bad sectors** reported by that scan.
- `sfc /scannow /offbootdir=D:\ /offwindir=D:\Windows` reported **no integrity violations**.
- `manage-bde -status D:` reported **fully decrypted**, **protection off**.
- `bcdedit` showed a Windows 11 loader referencing `D:` and a Windows Boot Manager on an EFI volume.
- Windows kept returning to recovery despite those checks.

## Resolution

After verifying the FAT32 EFI volume, a temporary letter `S:` was assigned. The EFI directory was inspected. Then:

```text
bcdboot D:\Windows /s S: /f UEFI
```

The console returned `Boot files successfully created.` The subsequent boot reached the Windows user welcome/sign-in screen.

## Interpretation

Recreating UEFI boot files was followed by a successful boot, consistent with an EFI boot-file/configuration problem. The exact original root cause was not independently proven. The result does not establish that every recovery loop has the same cause.
