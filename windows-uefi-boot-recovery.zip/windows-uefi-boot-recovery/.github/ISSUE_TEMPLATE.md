## Problem description

## Windows version and boot mode (UEFI/Legacy)

## Exact error message

## Steps already tried

## Disk/volume layout (remove serial numbers and personal data)

## Important notes
Do not share BitLocker recovery keys, passwords, or personal files.
