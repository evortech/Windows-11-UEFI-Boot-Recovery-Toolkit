# Windows 11 UEFI Boot Recovery Toolkit

A practical, **data-preserving** troubleshooting guide for Windows 11 systems that repeatedly enter Windows Recovery Environment (WinRE) instead of booting normally.

> **Outcome from the documented case:** Windows 11 successfully reached the user sign-in screen after EFI boot files were recreated with `bcdboot`. This is a case study, not a guaranteed fix for every boot failure.

## What this repository contains

- [Step-by-step recovery guide](docs/RECOVERY_GUIDE.md)
- [Case study and diagnostic results](docs/CASE_STUDY.md)
- [Safety checklist](docs/SAFETY.md)
- [`diagnose.cmd`](scripts/diagnose.cmd): read-only diagnostic commands for WinRE
- [`verify-efi.cmd`](scripts/verify-efi.cmd): read-only check of a *previously assigned* EFI drive letter

## Quick start

1. Open **Troubleshoot → Advanced options → Command Prompt** in Windows Recovery Environment.
2. Read [SAFETY.md](docs/SAFETY.md) before changing partitions or boot files.
3. Identify the Windows volume (`dir D:\Windows` is only an example; letters can change in WinRE).
4. Follow [RECOVERY_GUIDE.md](docs/RECOVERY_GUIDE.md) to check the disk and locate the EFI System Partition (ESP).
5. If the Windows directory and ESP have been positively identified, rebuild UEFI boot files with `bcdboot` as documented.
6. Exit Command Prompt and choose **Continue to Windows 11**. Back up important data once the system boots.

## Important cautions

**Never run `clean`, `format`, `delete partition`, or `convert` as part of this guide.** Do not assume the Windows partition is `C:` or `D:`. Do not assign the ESP based only on a volume number copied from someone else's computer. Back up critical data where possible. Systems using BitLocker may require a recovery key.

## Scope

Designed for Windows 11 installed in **UEFI/GPT** mode. This does not cover legacy BIOS/MBR repairs, hardware faults, or all causes of recovery loops. Some commands require administrative access. Scripts do not modify partitions or boot configuration.

## License

MIT — see [LICENSE](LICENSE).
